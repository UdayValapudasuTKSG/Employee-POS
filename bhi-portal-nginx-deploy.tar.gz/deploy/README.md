# NALICO / BHI Health Card Portal — nginx deployment package

This folder contains everything needed to run the portal on your own Linux server behind nginx.

```
deploy/
├── web/       → built frontend (static HTML/CSS/JS) — served by nginx
├── api/       → built API server (single-file Node app) + .env.example
├── db/        → schema.sql (PostgreSQL database schema)
├── nginx/     → bhi-portal.conf (nginx site config)
└── systemd/   → bhi-api.service (optional: run the API as a service)
```

## Prerequisites

- Ubuntu/Debian (or similar) server
- **Node.js 20+** (`node -v`)
- **PostgreSQL 14+**
- **nginx**

## 1. Set up the database

```bash
sudo -u postgres psql <<'SQL'
CREATE USER bhi_user WITH PASSWORD 'CHANGE_ME';
CREATE DATABASE bhi_portal OWNER bhi_user;
SQL

# Load the schema (new installation)
psql "postgresql://bhi_user:CHANGE_ME@localhost:5432/bhi_portal" -f db/schema.sql
```

**Upgrading an existing installation?** Skip `schema.sql` and run the
migrations instead (each is idempotent — safe to re-run):

```bash
for f in db/migrations/*.sql; do
  psql "postgresql://bhi_user:CHANGE_ME@localhost:5432/bhi_portal" -f "$f"
done
```

**No demo data is created in production.** The database starts empty; the
first administrator is created from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in
`.env` (step 2), and real companies and members are loaded in step 5.

## 2. Install the API server

Run these from the extracted `deploy/` folder:

```bash
sudo mkdir -p /opt/bhi-api
sudo cp -r api/. /opt/bhi-api/
sudo cp api/.env.example /opt/bhi-api/.env
sudo nano /opt/bhi-api/.env   # set DATABASE_URL, SESSION_SECRET, SMTP_*, PORT=3001

# Lock down the secrets file — it contains DB credentials and the session key
sudo chown -R www-data:www-data /opt/bhi-api
sudo chmod 600 /opt/bhi-api/.env
```

Test it manually:

```bash
cd /opt/bhi-api
set -a; source .env; set +a
node --enable-source-maps index.mjs
# → should log "Server listening" on port 3001
```

Run it permanently with systemd (again from the extracted `deploy/` folder):

```bash
sudo cp systemd/bhi-api.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now bhi-api
systemctl status bhi-api
```

**If the service fails to start**, check the logs and the two paths it uses:

```bash
journalctl -u bhi-api -n 30 --no-pager   # shows the actual error
which node                               # where Node is installed
ls /opt/bhi-api/index.mjs                # the app file must exist here
```

- The unit runs `node` via `/usr/bin/env`, so it works with most installs.
  If Node was installed with **nvm**, systemd can't find it — edit
  `/etc/systemd/system/bhi-api.service` and replace the `ExecStart` line
  with the full path from `which node`, then run
  `sudo systemctl daemon-reload && sudo systemctl restart bhi-api`.
- If you installed the app somewhere other than `/opt/bhi-api`, update
  `WorkingDirectory`, `EnvironmentFile`, and `ExecStart` in the unit to match.
```

## 3. Install the frontend

```bash
sudo mkdir -p /var/www/bhi-portal
sudo cp -r web/. /var/www/bhi-portal/
```

## 4. Configure nginx

```bash
sudo cp nginx/bhi-portal.conf /etc/nginx/sites-available/
sudo ln -s /etc/nginx/sites-available/bhi-portal.conf /etc/nginx/sites-enabled/
# Optional: remove the default site
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

Edit `server_name` in the config to your domain. The config:
- serves the static frontend from `/var/www/bhi-portal`
- proxies `/api/...` to the Node API on `127.0.0.1:3001`
- falls back to `index.html` for app routes (SPA)

Open `http://your-server/` — the portal should load.

## 5. Load your company and member data

Production starts with an empty database. Load your real data like this:

**a) Create your companies** (one row per company; `code` is a short unique
identifier that appears on member records):

```bash
psql "postgresql://bhi_user:CHANGE_ME@localhost:5432/bhi_portal" <<'SQL'
INSERT INTO companies (code, name) VALUES
  ('ACME', 'Acme Holdings Ltd'),
  ('ACML', 'Acme Logistics Ltd');
SQL
```

**b) Import members from CSV** — sign in to the admin portal at
`http://your-server/admin/login` with your `ADMIN_EMAIL` account, open
**Import**, and paste CSV rows with exactly this header:

```
employeeNumber,firstName,lastName,dateOfBirth,identificationId,email,phone,companyCode
```

The import previews every row first (dry run) and reports errors before
anything is committed. After importing, an employee lookup by a member's
email or phone will send them a verification code (step: configure `SMTP_*`
first).

You can also add additional HR admin accounts from the admin portal's
Admins screen.

## 6. HTTPS (recommended)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## Notes

- **Verification codes**: real email/SMS delivery is now built into the
  server (this supersedes the earlier plan to keep it commented out).
  Employee card lookups send a one-time code by email (any SMTP provider)
  or SMS (a webhook to your SMS gateway). Fill in the `SMTP_*` (and
  optionally `SMS_WEBHOOK_*`) values in `.env` — see `.env.example`. If no
  provider is configured, lookups return a clear "codes cannot be
  delivered" error instead of silently claiming a code was sent.
- **Demo/staging without an email provider**: set `OTP_DEV_MODE=true` in
  `.env` to show codes on screen so you can try the portal before wiring up
  SMTP. Never leave this enabled on a real production server — anyone who
  knows a member's email or phone number could read their card.
- **Network exposure**: the API binds to `127.0.0.1` (see `HOST` in `.env`),
  so nginx is the only public entry point. Keep it that way, or add a
  firewall rule if you change the bind address.
- **PostgreSQL version**: `db/schema.sql` was generated with PostgreSQL 16.
  Use PostgreSQL 14+ for the server; load the schema with a `psql` client
  version 14 or newer (the dump has been made portable — no
  version-specific commands remain).
- **First administrator**: no demo data or default accounts are created in
  production. On first start against an empty database, the API creates one
  group administrator from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env`
  (set a strong unique password). Additional HR admins can then be added
  from the admin portal. `DEMO_SEED=true` (sample members + demo admin
  accounts with publicly known passwords) is for throwaway demo/staging
  databases only — never production.
- To update the app later: rebuild in the project, then re-copy `web/` and
  `api/index.mjs` and restart `bhi-api`.
