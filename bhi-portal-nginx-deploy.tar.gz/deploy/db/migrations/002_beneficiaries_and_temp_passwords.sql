-- Upgrade migration for existing installations (idempotent).
-- Adds the beneficiaries table and the temporary-password flag on admins.
-- New installations that loaded schema.sql already include these.

CREATE TABLE IF NOT EXISTS beneficiaries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    relationship text NOT NULL,
    date_of_birth date NOT NULL,
    allocation_percent integer,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    removed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'beneficiaries_pkey'
  ) THEN
    ALTER TABLE beneficiaries ADD CONSTRAINT beneficiaries_pkey PRIMARY KEY (id);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'beneficiaries_member_id_employee_members_id_fk'
  ) THEN
    ALTER TABLE beneficiaries
      ADD CONSTRAINT beneficiaries_member_id_employee_members_id_fk
      FOREIGN KEY (member_id) REFERENCES employee_members(id);
  END IF;
END $$;

ALTER TABLE admin_users
  ADD COLUMN IF NOT EXISTS must_change_password boolean DEFAULT false NOT NULL;
