-- Upgrade migration for existing installations (idempotent).
-- Adds the raw destination column used to resend verification codes.
-- New installations that loaded schema.sql already include this column.

ALTER TABLE verification_sessions
  ADD COLUMN IF NOT EXISTS destination text;
